﻿'use strict';

angular.module('app')
    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/app/$itemname$', {
            label: '$itemname$',
            templateUrl: 'app/$itemname$.html',
            controller: '$itemname$Controller'
        });
    }])
    .controller("$itemname$Controller", ["$scope", "$http", function ($scope, $http) {
        $scope.$parent.child = $scope;
        $scope.status = "loading";

        $http.get("/api/$itemname$")
            .success(function (response) {
                $scope.response = response;
            })
            .finally(function () {
                $scope.status = "loaded";
            });
    }]);