﻿'use strict';

describe('app module', function () {
    beforeEach(module('app'));

    describe('$itemname$Controller controller', function () {
        it('should ....', inject(function ($controller) {
            var controller = $controller('$itemname$Controller');
            expect(controller).toBeDefined();
        }));
    });
});